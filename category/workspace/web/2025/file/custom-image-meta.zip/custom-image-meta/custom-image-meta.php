<?php
/*
Plugin Name: Custom Image Meta for Posts
Description: REST API에서 사용할 게시물에 맞춤 메타 필드 'image_urls'를 등록합니다.
Version: 1.0
Author: sori.studio
*/

function register_image_urls_meta() {
    register_post_meta('post', 'image_urls', [
        'type'         => 'string',
        'single'       => true,
        'show_in_rest' => true,
        'sanitize_callback' => 'sanitize_text_field',
    ]);
}
add_action('init', 'register_image_urls_meta');
?>
