<?php
/*
Plugin Name: Custom REST User Register
Description: REST API를 통해 사용자 등록 기능 제공
Version: 1.0
Author: sori.studio
*/

add_action('rest_api_init', function () {
    register_rest_route('custom-register/v1', '/register', array(
        'methods' => 'POST',
        'callback' => 'custom_rest_user_register',
        'permission_callback' => '__return_true'
    ));
});

function custom_rest_user_register($request) {
    $params = $request->get_json_params();

    $username = sanitize_text_field($params['username']);
    $email = sanitize_email($params['email']);
    $password = $params['password'];
    $nickname = sanitize_text_field($params['nickname']);

    if (username_exists($username) || email_exists($email)) {
        return new WP_Error('user_exists', '이미 존재하는 사용자입니다.', array('status' => 400));
    }

    $user_id = wp_create_user($username, $password, $email);

    if (is_wp_error($user_id)) {
        return $user_id;
    }

    wp_update_user(array(
        'ID' => $user_id,
        'nickname' => $nickname,
        'role' => 'author'
    ));

    return array('success' => true, 'message' => '회원가입 완료');
}
