<?php
/**
 * Plugin Name: Set Display Name to Nickname
 * Description: 회원 가입 시 display_name을 nickname으로 자동 설정합니다.
 * Version: 1.0
 * Author: sori.studio
 */

if (!defined('ABSPATH')) {
    exit; // 직접 접근 방지
}

function sdnn_set_display_name_to_nickname($user_id) {
    $user = get_userdata($user_id);
    $nickname = $user->nickname;

    if (!empty($nickname)) {
        wp_update_user([
            'ID' => $user_id,
            'display_name' => $nickname
        ]);
    }
}
add_action('user_register', 'sdnn_set_display_name_to_nickname');
